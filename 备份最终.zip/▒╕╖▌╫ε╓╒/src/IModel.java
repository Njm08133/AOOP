public interface IModel {
    void Add_String(String s);

    Boolean Is_Enter();

    void back();

    int[] validateExpression();

    int getLine_num();

    void setLine_num(int line_num);

    void Clear_All();

    void Restart();

    String[] getUser_String();

    void notifyObserver();

    void setChage();
}
