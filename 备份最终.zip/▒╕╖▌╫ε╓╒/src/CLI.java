import java.util.Scanner;

public class CLI {
    public static void main(String[] args) {
        Model model = new Model();
        // Create model objects
        System.out.println("Enter an equation of length 7 (including symbols)");
        System.out.println("Start the game");
        // Prompt the user to start the game
        Scanner scanner = new Scanner(System.in);
        // Create a Scanner object to receive user input
        int attempts = 0;
        boolean gameOver = false;
        while (!gameOver && attempts < 6) {
            String s = scanner.nextLine();
            // Read the equation entered by the user
            char[] chars = s.toCharArray();
            // Convert the equation to a character array
            if (chars.length != 7) {
                // Check if the length of the equation is 7
                System.out.println("Equation formatting error");
            } else {
                for (int i = 0; i < chars.length; i++) {
                    // Add the characters in the equation to the model one by one
                    model.Add_String(String.valueOf(chars[i]));
                }
                int[] verify = model.validateExpression();
                // Verify the equation
                if (verify[0] == -1 || verify[0] == -2 || verify[0] == -3) {
                    // Check the verification result
                    System.out.println("Equality error");
                    model.Clear_All();
                    System.out.println("Please re-enter the equation:");
                } else if (verify[0] == 6) {
                    System.out.println("Game over. You failed");
                    gameOver = true;
                } else if (verify[0] == 7) {
                    System.out.println("Game over. You won");
                    gameOver = true;
                } else {
                    boolean validPosition = true;
                    for (int i = 0; i < verify.length; i++) {
                        if (verify[i] == 2) {
                            System.out.println(model.getUser_String()[i] + " - This character does not exist in the equation");
                        } else if (verify[i] == 1) {
                            System.out.println(model.getUser_String()[i] + " - This character exists in the equation but position is incorrect");
                            validPosition = false;
                        } else if (verify[i] == 0) {
                            System.out.println(model.getUser_String()[i] + " - This character exists in the equation and the position is correct");
                        }
                    }
                    if (!validPosition) {
                        model.Clear_All();
                        System.out.println("Please re-enter the equation:");
                        attempts++;
                    }
                }
            }
        }
        if (!gameOver) {
            System.out.println("Game over. You lost");
        }
    }
}
