public class GUI {
    public static void main(String[] args) {
        Model model=new Model();
        Control page_control=new Control(model);
        page_control.Start_Game();
    }
}
