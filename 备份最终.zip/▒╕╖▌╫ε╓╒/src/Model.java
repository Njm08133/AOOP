import java.io.*;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Random;

public class Model extends Observable implements IModel {
    ArrayList<Observer> observers=new ArrayList<>();
    private String[] user_String = new String[7]; // 用户输入的当前字符

    private ArrayList<String> equationList; // 从txt读取的公式集合

    public String answer; // 正确答案
    private int line_num = 0; // 当前行数/机会

    public Model() {

        try {
            ArrayList<String> strings = new ArrayList<>();
            String pathname = "equations.txt"; // 绝对路径或相对路径都可以，这里是绝对路径，写入文件时演示相对路径
            File filename = new File(pathname); // 要读取以上路径的input。txt文件
            InputStreamReader reader = new InputStreamReader(
                    new FileInputStream(filename)); // 建立一个输入流对象reader
            BufferedReader br = new BufferedReader(reader); // 建立一个对象，它把文件内容转成计算机能读懂的语言
            String line = "";
            line = br.readLine();
            while (line != null) {
                line = br.readLine(); // 一次读入一行数据
                strings.add(line);
            }
            equationList = strings;
            Get_Answer();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /**
     * @pre. s must not be null.
     * @post. Adds the provided string s to the user_String array.
     **/
    // 添加用户的字符
    public void Add_String(String s) {
        // Preconditions
        assert s != null : "Input string 's' must not be null.";

        for (int i = 0; i < user_String.length; i++) {
            if (user_String[i] == null) {
                user_String[i] = s;
                break;
            }
        }

        // Postconditions
        boolean stringAdded = false;
        for (String str : user_String) {
            if (str != null && str.equals(s)) {
                stringAdded = true;
                break;
            }
        }
        assert stringAdded : "String 's' was not added to the user_String array.";
    }


    /**
     * @pre. null
     * @post. Returns true if all characters in user_String have lengths greater than or equal to 7; otherwise, returns false.
     */
    // 判断用户是否可以继续输入字符
    public Boolean Is_Enter() {
        for (int i = 0; i < user_String.length; i++) {
            if (user_String[i] == null || user_String[i].length() < 7) {
                return false; // 如果有任何一个字符长度小于7，直接返回false
            }
        }
        return true; // 如果所有字符长度都大于等于7，返回true
    }


    /**
     * @pre. null
     * @post. Removes the last entered character from user_String if there are characters entered.
     */
    //用户回退字符
    public void back() {
        boolean is = true;
        for (int i = 0; i < user_String.length; i++) {
            if (user_String[i] == null) {
                if (i == 0) {
                    return;
                }
                user_String[i - 1] = null;
                is = false;
            }
        }
        if (is) {
            user_String[6] = null;
        }
        // Postconditions
        // After calling back(), the last entered character should be removed from user_String if characters were entered.
        assert (user_String[user_String.length - 1] == null) : "Last entered character should be removed.";

    }

    /**
     * @pre. The user must have entered at least 7 characters/The input string array must not be null.
     * @post. Returns an array representing the validation result of the entered expression:
     * If the entered characters are not enough, returns {-1}.
     * If the entered expression lacks an equals sign '=', returns {-2}.
     * If the entered expression is correct, returns {7}.
     * If the user has run out of chances (line_num reaches 5), returns {6}.
     * If the entered expression is incorrect, returns {-3}.
     */
    //验证用户输入的表达式
    public int[] validateExpression() {
        // Preconditions
        assert Is_Enter() : "Input characters are not enough for validation.";
        assert user_String != null : "user_String array must not be null for validation.";
        // 验证表达式是否完整,是否有等号
        boolean valid = false;
        for (int i = 0; i < user_String.length; i++) {
            if (user_String[i] != null && user_String[i].equals("=")) {
                valid = true;
                break;
            }
        }

        if (!valid) {
            return new int[]{-1}; // 等式不完整
        }

        // 验证表达式是否有加减乘除
        valid = false;
        for (int i = 0; i < user_String.length; i++) {
            if (user_String[i] != null && (user_String[i].equals("+") || user_String[i].equals("-") || user_String[i].equals("*") || user_String[i].equals("/"))) {
                valid = true;
                break;
            }
        }

        if (!valid) {
            return new int[]{-2}; // 等式不完整
        }

        // 验证表达式是否正确
        int[] ints = new int[7];
        StringBuilder s = new StringBuilder();
        StringBuilder s1 = new StringBuilder();
        int i1 = 0;
        for (int i = 0; i < user_String.length; i++) {
            if (user_String[i] != null && user_String[i].equals("=")) {
                i1 = i;
                break;
            } else {
                s.append(user_String[i]);
            }
        }

        for (int i = i1 + 1; i < user_String.length; i++) {
            s1.append(user_String[i]);
        }

        Calculator calculator = new Calculator();
        int eval = calculator.calcExpresion(s.toString());
        int eval1 = calculator.calcExpresion(s1.toString());

        if (eval == eval1) {
            char[] chars = answer.toCharArray();
            char[] chars1 = (s + "=" + s1).toCharArray();
            for (int i = 0; i < chars.length; i++) {
                if (chars[i] == chars1[i]) {
                    ints[i] = 0; // 字符包含且在正确位置上
                } else {
                    boolean is = false;
                    for (int j = 0; j < chars.length; j++) {
                        if (chars[j] == chars1[i]) {
                            ints[i] = 1; // 包含但是不在正确位置上
                            is = false;
                            break;
                        } else {
                            is = true;
                        }
                    }

                    if (is) {
                        ints[i] = 2; // 不包含这个数字
                    }
                }
            }

            boolean is = true;
            for (int i = 0; i < ints.length; i++) {
                if (ints[i] != 0) {
                    is = false;
                    break;
                }
            }
            if (is) {
                return new int[]{7}; // 等式正确
            } else {
                if ((5 - line_num) == 0) {
                    return new int[]{6}; // 机会用尽
                }
            }

        } else {
            return new int[]{-3}; // 等式不成立
        }
        // Postconditions
        assert user_String != null : "Result array must not be null after validation.";

        return ints;
    }


    /**
     * @pre. The precondition for this method is that the current object must have a valid line number (line_num) set, otherwise it might lead to unpredictable results.
     * @post. The postcondition for this method is that it returns the line number (line_num) of the current object as a result, which should be a valid integer value.
     */
    public int getLine_num() {
        assert invariant() : "Line number cannot be negative";
        return line_num;
    }


    /**
     * @pre. The precondition of this method is to accept an integer parameter line_num, which represents the line number to be set.
     * @post. The postcondition of this method is to set the object's line_num attribute to the value of the passed line_num parameter.
     */
    public void setLine_num(int line_num) {
        // Precondition
        assert invariant() : "Line number must be a non-negative integer";
        this.line_num = line_num;

    }


    /**@pre. The user_String array must not be null./The user_String array length must be greater than zero.
     * @post. All elements in the user_String array will be set to null.
     */
    /**
     * 清空字符数组
     */
    public void Clear_All() {
        assert user_String != null : "Precondition failed: user_String array must not be null";
        assert user_String.length > 0 : "Precondition failed: user_String array length must be greater than zero";

        for (int i = 0; i < user_String.length; i++) {
            user_String[i] = null;
            assert user_String[i] == null : "Postcondition failed: Element at index " + i + " is not null";
        }

    }

    /**@pre.     The Restart() method assumes that the environment is in a state where the Clear_All() method can be safely executed.
    The Restart() method expects that line_num is appropriately initialized.
    The Restart() method relies on the availability and correctness of the Get_Answer() method.
    * @post.    Upon successful execution of Restart(), all relevant data or variables that need to be cleared are reset.
     * The value of line_num is set to 0 after the execution of Restart().
     * The method Restart() ensures that the program is ready to fetch a new answer using the Get_Answer() method.
    */
    public void Restart() {
        //Precondition
        assert user_String != null : "The user_String array must not be null for Restart() method.";
        assert line_num >= 0 : "The line_num must be a non-negative integer for Restart() method.";
        Clear_All();
        line_num = 0;
        Get_Answer();
        //Postcondition
        assert user_String != null : "The user_String array is null after Restart() method execution.";
        assert line_num == 0 : "The line_num is not reset to 0 after Restart() method execution.";
    }


    /**@pre.     The method assumes that the user_String array is not null.
    The method assumes that the length of the user_String array is greater than zero.
     * @post.    All elements in the user_String array will be returned.
     */
    public String[] getUser_String() {
        //Precondition
        assert user_String != null : "Precondition failed: user_String array must not be null";
        assert user_String.length > 0 : "Precondition failed: user_String array length must be greater than zero";
        return user_String;
    }


    /**@pre.      The equationList ArrayList must not be null.
    The equationList ArrayList must contain at least one equation.
     * @post.     The answer variable will be set to a randomly selected equation from the equationList.
     * The answer variable will contain a valid equation string.
     */
    private void Get_Answer() {
        //Precondition
        assert equationList != null : "The equationList ArrayList must not be null.";
        assert !equationList.isEmpty() : "The equationList ArrayList must contain at least one equation.";

        answer = equationList.get(new Random().nextInt(equationList.size())); // 从正确公式中随机选择一个公式作为正确答案

        //Postcondition
        assert answer != null : "The answer variable must not be null.";
        assert !answer.isEmpty() : "The answer variable must contain a valid equation string.";

    }



    /**@pre.     The observer parameter must not be null.
     * @post.    The observer is added to the list of observers.
     */
    //添加观察者
    public void addObserver(Observer observer){
        //Preconditio
        // assert observer != null : "Observer parameter must not be null.";

        observers.add(observer);

        //Postcondition
        //assert observers.contains(observer) : "Observer was not added to the list of observers.";

    }


    /**@pre.       The observers ArrayList must not be null./The observers ArrayList must contain at least one Observer object.
     * @post.      After execution, all observers in the observers ArrayList are notified by calling their Update() method.
     */
    //更新通知
    @Override
    public void notifyObserver(){
        //Precondition
//        assert observers != null : "Precondition failed: observers ArrayList must not be null";
//        assert !observers.isEmpty() : "Precondition failed: observers ArrayList must contain at least one Observer object";

        //将更新消息通知到每一个观察者
        for(Observer item:observers){
            item.Update();
        }
    }

    /**@pre.     null
     * @post. The method triggers a change in the state of the object.
     * All observers registered with the object are notified of the state change.
     */
    @Override
    public void setChage(){
        setChage();
        notifyObserver();

        //Postcondition
        // Since this method internally calls another method to change the state and then notifies the observers, we can ensure that the state change has occurred and the observers are notified.
        assert true : "State change triggered and observers notified successfully.";
    }

    public boolean invariant(){
        return line_num >= 0;
    }

}
