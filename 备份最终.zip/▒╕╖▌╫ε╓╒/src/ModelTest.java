import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ModelTest {

    @Test
    public void testValidateExpression() {
        // 准备测试数据
        Model model = new Model();
        model.Add_String("2");
        model.Add_String("+");
        model.Add_String("3");
        model.Add_String("*");
        model.Add_String("1");
        model.Add_String("/");
        model.Add_String("5");

        // 执行测试
        int[] result = model.validateExpression();

        // 断言
        assertArrayEquals(new int[]{-1}, result); // 没有等号，预期结果应返回 {-1}
    }


    @Test
    public void inputFieldTest() {
        Model model = new Model();

        // Scenario 2: Input Field Limit Reached
        model.Clear_All();
        model.Add_String("1");
        model.Add_String("2");
        model.Add_String("3");
        model.Add_String("4");
        model.Add_String("=");
        model.Add_String("5");
        model.Add_String("6");
        assertFalse(model.Is_Enter()); // Expecting input field limit reached
    }


    @Test
    public void testNewGame() {
        Model model = new Model();

        // Simulate a game with progress
        model.Add_String("1");
        model.Add_String("+");
        model.Add_String("2");
        model.Add_String("=");
        model.Add_String("3");
        model.validateExpression();
        model.setLine_num(2);

        // Restart the game
        model.Restart();

        // Verify game is reset
        assertNull(model.getUser_String()[0]);
        assertEquals(0, model.getLine_num());
    }
}