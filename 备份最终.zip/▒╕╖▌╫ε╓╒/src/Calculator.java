import java.util.ArrayDeque;
import java.util.Deque;

public class Calculator {

    // 计算中缀表达式的结果
    public int calcExpresion(String expression) {
        expression = expression.replaceAll("\\s", ""); // 移除空格

        Deque<Integer> operandStack = new ArrayDeque<>();
        Deque<Character> operatorStack = new ArrayDeque<>();

        for (char c : expression.toCharArray()) {
            if (Character.isDigit(c)) {
                operandStack.push(c - '0'); // 将字符转换为数字
            } else if (isOperator(c)) {
                while (!operatorStack.isEmpty() && precedence(operatorStack.peek()) >= precedence(c)) {
                    calculate(operandStack, operatorStack);
                }
                operatorStack.push(c);
            }
        }

        while (!operatorStack.isEmpty()) {
            calculate(operandStack, operatorStack);
        }

        return operandStack.pop();
    }

    private boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/';
    }

    private int precedence(char operator) {
        if (operator == '+' || operator == '-') {
            return 1;
        } else {
            return 2;
        }
    }

    private void calculate(Deque<Integer> operandStack, Deque<Character> operatorStack) {
        char operator = operatorStack.pop();
        int operand2 = operandStack.pop();
        int operand1 = operandStack.pop();
        int result;
        switch (operator) {
            case '+':
                result = operand1 + operand2;
                break;
            case '-':
                result = operand1 - operand2;
                break;
            case '*':
                result = operand1 * operand2;
                break;
            case '/':
                if (operand2 != 0) {
                    result = operand1 / operand2;
                } else {
                    throw new ArithmeticException("除数不能为0");
                }
                break;
            default:
                throw new RuntimeException("无效的操作符");
        }
        operandStack.push(result);
    }
}
