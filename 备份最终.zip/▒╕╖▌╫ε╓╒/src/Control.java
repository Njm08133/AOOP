import javax.script.ScriptException;
import javax.swing.*;
import java.awt.event.*;

public class Control {
    private Model model;
    private View view;

    public Control(Model model) {
        this.model = model;
    }

    public ActionListener GetJButton_Listener() {
        ActionListener actionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton jButton = (JButton) e.getSource();
                if ("Back".equals(jButton.getText())) {
                    model.back();
                    model.notifyObserver();
                    Update();
                } else if ("Enter".equals(jButton.getText())) {
                    int[] verify;
                    try {
                        verify = model.validateExpression();
                    } catch (Exception ex) {
                        throw new RuntimeException(ex);
                    }
                    switch (verify[0]) {
                        case -1:
                            getView().Show_Dialog(0, "");
                            break;
                        case -2:
                        case -3:
                            getView().Show_Dialog(1, "");
                            break;
                        case 6:
                            getView().Show_Dialog(3, ""); // Handle game over scenario
                            break;
                        case 7:
                            getView().Ok_Show(-1, model.getLine_num() * 7, "ok");
                            getView().Show_Dialog(4, "");
                            break;
                        default:
                            if (verify.length == 7) {
                                for (int i = 0; i < verify.length; i++) {
                                    getView().Ok_Show(verify[i], i + (model.getLine_num() * 7), model.getUser_String()[i]);
                                }
                            }
                            model.Clear_All();
                            model.setLine_num(model.getLine_num() + 1);
                            break;
                    }
                } else {
                    model.Add_String(jButton.getText());
                    model.notifyObserver();
                    Update();
                }
                getView().setFocusable(true);
            }
        };
        return actionListener;
    }

//    private void handleInput(int keyCode) {
//        String input = "";
//        switch (keyCode) {
//            case KeyEvent.VK_1:
//                input = "1";
//                break;
//            case KeyEvent.VK_2:
//                input = "2";
//                break;
//            case KeyEvent.VK_3:
//                input = "3";
//                break;
//            case KeyEvent.VK_4:
//                input = "4";
//                break;
//            case KeyEvent.VK_5:
//                input = "5";
//                break;
//            case KeyEvent.VK_6:
//                input = "6";
//                break;
//            case KeyEvent.VK_7:
//                input = "7";
//                break;
//            case KeyEvent.VK_8:
//                input = "8";
//                break;
//            case KeyEvent.VK_9:
//                input = "9";
//                break;
//            case KeyEvent.VK_0:
//                input = "0";
//                break;
//            case KeyEvent.VK_MULTIPLY:
//                input = "*";
//                break;
//            case KeyEvent.VK_ADD:
//                input = "+";
//                break;
//            case KeyEvent.VK_SUBTRACT:
//                input = "-";
//                break;
//            case KeyEvent.VK_DIVIDE:
//                input = "/";
//                break;
//            case KeyEvent.VK_EQUALS:
//                input = "=";
//                break;
//        }
//        model.Add_String(input);
//        model.notifyObserver();
//    }

    public void Start_Game() {
        View page = new View(this, model);
        page.setVisible(true);
        page.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.view = page;
    }

    public View getView() {
        return view;
    }

    public void Update() {
        for (int i = 0; i < model.getUser_String().length; i++) {
            getView().Add_String(model.getUser_String()[i] != null ? model.getUser_String()[i] : "", i + (model.getLine_num() * 7));
        }
    }

    public void Game_Over(int i) {
        if (i == 0) {
            model.Restart();
            getView().dispose();
            Start_Game();
        } else {
            System.exit(0);
        }
    }
}
