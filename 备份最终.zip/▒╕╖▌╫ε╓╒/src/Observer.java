public interface Observer {
    void Update();
}
