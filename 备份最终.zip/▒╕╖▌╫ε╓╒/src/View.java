import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

public class View extends JFrame implements Observer {
    private Control control;
    private Model model;
    private HashMap<Integer, JTextField> jTextFields; // Input fields mapped by index
    private HashMap<String, JButton> jButtons; // Buttons mapped by text


    public View(Control control, Model model) {
        this.control = control;
        this.model = model; // Initialize Model reference
        model.addObserver(this); // Add View as an observer to the Model
        initialize();
    }


    public Control getControl() {
        return control;
    }

    public void setControl(Control control) {
        this.control = control;
    }

    /**
     * Initialize the interface
     */
    public void initialize() {
        JPanel jPanel = new JPanel(); // Middle panel

        jTextFields = new HashMap<>(); // Input fields mapped by index
        jButtons = new HashMap<>(); // Buttons mapped by text

        // Add input fields
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                JTextField jTextField = new JTextField();
                jTextField.setPreferredSize(new Dimension(100, 100));
                jTextField.setHorizontalAlignment(JTextField.CENTER);
                jTextField.setFont(new Font("12", 23, 33));
                jTextField.setFocusable(false);
                jTextField.setEditable(false);
                jTextFields.put(i * 7 + j, jTextField);
                jPanel.add(jTextField);
            }
        }

        // Create virtual keyboard buttons
        String[] buttonLabels = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
                "+", "-", "*", "/", "=", "Back", "Enter"};
        for (String label : buttonLabels) {
            JButton jButton = new JButton(label);
            jButton.setPreferredSize(new Dimension(80, 40));
            jButtons.put(label, jButton); // Add button to HashMap
        }

        // Add virtual keyboard to the panel
        JPanel jPanel1 = new JPanel();
        for (String label : buttonLabels) {
            jPanel1.add(jButtons.get(label));
        }

        // Add action listeners to virtual keyboard buttons
        for (JButton button : jButtons.values()) {
            button.addActionListener(control.GetJButton_Listener());
        }

        // Add the "New Game" button
        JButton newGameButton = new JButton("New Game");
        newGameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int choice = JOptionPane.showConfirmDialog(View.this,
                        "您将开始新的游戏，确认或取消", "确认", JOptionPane.OK_CANCEL_OPTION);
                if (choice == JOptionPane.OK_OPTION) {
                    control.Game_Over(0); // Restart the game
                }
            }
        });
        jPanel1.add(newGameButton);

        jPanel1.setLayout(new FlowLayout(FlowLayout.LEADING, 15, 15)); // Set keyboard layout and spacing
        jPanel.setLayout(new GridLayout(6, 7, 20, 20)); // Set input field layout and spacing
        jPanel.setPreferredSize(new Dimension(880, 600)); // Set input field panel size
        jPanel1.setPreferredSize(new Dimension(880, 180)); // Set virtual keyboard size

        setFocusable(true);
        add(BorderLayout.CENTER, jPanel); // Add panel to the window
        add(BorderLayout.SOUTH, jPanel1);
        setBounds(400, 20, 880, 800); // Set page size and position
    }


    /**
     * Display the string input by the player in the specified input field
     *
     * @param str   String input by the player
     * @param index Index of the input field
     */
    public void Add_String(String str, int index) {
        jTextFields.get(index).setText(str);
    }

    /**
     * Display validation results
     */
    public void Ok_Show(int i, int index, String s) {
        JTextField textField = jTextFields.get(index);
        JButton button = jButtons.get(s);

        switch (i) {
            case 2:
                textField.setBackground(Color.gray);
                button.setBackground(Color.gray);
                break;
            case 1:
                textField.setBackground(Color.orange);
                button.setBackground(Color.orange);
                break;
            case 0:
                textField.setBackground(Color.GREEN);
                button.setBackground(Color.GREEN);
                break;
            case -1:
                for (int j = index; j < index + 7; j++) {
                    jTextFields.get(j).setBackground(Color.GREEN);
                }
                repaint();
                break;
        }
    }

    public void Show_Dialog(int i, String s) {
        if (i == 0 || i == 1) {
            JOptionPane.showMessageDialog(this, "等式错误", "Title", JOptionPane.ERROR_MESSAGE);
//        } else if (i == 2) {
//            JOptionPane.showMessageDialog(this, "猜测错误，请继续 "+s, "提示", JOptionPane.INFORMATION_MESSAGE);
        } else if (i == 3) {
            Object[] options = {"重新开始", "退出游戏"}; // 新增退出游戏选项
            int choice = JOptionPane.showOptionDialog(null, "你输了! 正确答案是：" + model.answer, "游戏结束", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
            if (choice == JOptionPane.YES_OPTION) {
                control.Game_Over(0); // 重新开始游戏
            } else {
                // 退出游戏逻辑
                System.exit(0); // 直接退出程序
            }
        } else if (i == 4) {
            Object[] options = {"重新开始", "退出游戏"}; // 新增退出游戏选项
            int choice = JOptionPane.showOptionDialog(null, "你赢了", "游戏结束", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
            if (choice == JOptionPane.YES_OPTION) {
                control.Game_Over(0); // 重新开始游戏
            } else {
                // 退出游戏逻辑
                System.exit(0); // 直接退出程序
            }
        }
    }

    public void Restart() {
        model.Restart(); // 调用模型的重新开始方法
    }


    @Override
    public void Update() {
        control.Update();
    }


}
